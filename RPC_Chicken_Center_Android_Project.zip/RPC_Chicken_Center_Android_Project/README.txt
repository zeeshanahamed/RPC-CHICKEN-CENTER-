RPC CHICKEN CENTER Android project source

This is an Android Studio project that wraps the RPC Chicken Center billing manager in an Android WebView.
It is source code, NOT a prebuilt APK. This environment did not have the Android SDK/Gradle build toolchain to compile an APK here.

Build APK:
1. On a computer, install Android Studio.
2. Extract this ZIP.
3. Android Studio > Open > select the RPC_Chicken_Center_Android_Project folder.
4. Let Gradle sync and install any requested Android SDK platform (API 35).
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When build completes, choose Locate. The APK is normally in app/build/outputs/apk/debug/app-debug.apk.
7. Transfer the APK to your Android phone and install it. Android may ask you to allow installs from that file app.

App data is saved locally on this phone/browser storage. Keep regular backups from the app's Backup section. Do not clear app data if you need old records.
